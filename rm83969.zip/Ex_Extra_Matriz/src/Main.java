import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);		
		int option = 0; 
		
		// Array de produtos
		int codProd[] = new int[5];
		String descProd[] = new String[5];
		
		// Array Lojas
		
		String nomeLojas[] = new String[6];
		
		// Array de precos
		
		int precos[]= new int[5];
		
		
	
		do {
			System.out.println("1 - Cadastrar produtos");
			System.out.println("2 - Cadastrar lojas");
			System.out.println("3 - Cadastrar precos");
			System.out.println("4 - Procurar menor de preco de produto");
			System.out.println("5 - Listar todos os produtos cadastrados");
			System.out.println("6 - Sair");
			
			option = input.nextInt();
			
			switch (option) {
				case 1:
				    
				    CadastraProd cadastraProd = new CadastraProd();
				    cadastraProd.cadastra(codProd, descProd);
				    
				    break;
				case 2:
					
				    CadastraStore cadastraStore = new CadastraStore();	           
				    
				    cadastraStore.cadastra(nomeLojas);
				    
				    break;
				case 3:
					
				    System.out.println("3");
				    CadastraPreco cadastraPreco = new CadastraPreco();	           
				    
				    cadastraPreco.cadastra(precos);
				    
				    break;
				case 4:
				    System.out.println("4");
				    ProcuraProdPreco procuraMenorPreco = new ProcuraProdPreco();
				    
				    procuraMenorPreco.procura();
				    
				    break;
				case 5:
				    
					System.out.println("5");
				    ListaProd listaProd = new ListaProd();
				    
				    listaProd.listar(codProd, descProd);
				    
				    break;
				case 6:
				    System.out.println("Tchau!");
				    System.exit(0);
				    
				    break;
				default:
					System.out.println("Op��o inv�lida!");
			 }
		
		} while(option!=6);
		
		input.close();
	}
}
