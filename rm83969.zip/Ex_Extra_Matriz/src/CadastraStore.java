import java.util.Scanner;

public class CadastraStore {
	
	public void cadastra(String[] nomeLojas) {
		Scanner input = new Scanner(System.in);		
		
		for ( int i = 0; i < nomeLojas.length; i++ ) {
	     	System.out.println("Qual o nome do produto?");
	     	
	     	nomeLojas[i] = input.next();
	    }
		
		input.close();
	}
}
