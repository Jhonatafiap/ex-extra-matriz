import java.util.Scanner;

public class CadastraProd {
	public void cadastra(int[] codProd, String[] descProd) {
		
		Scanner input = new Scanner(System.in);		
		
		for ( int i = 0; i < codProd.length; i++ ) {
         	System.out.println("Qual o nome do produto?");
         	descProd[i] = input.next();
         	
         	System.out.println("E o c�digo?");
         	codProd[i] = input.nextInt();
         }
		
		input.close();
	}
}
