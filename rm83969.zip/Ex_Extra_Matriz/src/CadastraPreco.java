import java.util.Scanner;

public class CadastraPreco {
	public void cadastra(int[] precos) {
			
		Scanner input = new Scanner(System.in);		
		int i = 0;
		
		while ( i < precos.length ) {
			if ( precos[i] > 0 ) {
				System.out.println("Qual o pre�o do produto?");
		     	
		     	precos[i] = input.nextInt();	
			}
		}
		
		input.close();
	}
}
