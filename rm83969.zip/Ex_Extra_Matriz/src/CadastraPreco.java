import java.util.Scanner;

public class CadastraPreco {
	public void cadastra(int codProd[], String descProd[], String nomeLojas[], double precoStore[][]) {
			
		Scanner input = new Scanner(System.in);		
		
		for ( int i = 0; i < 5; i++ ) {
			System.out.println("Digite os pre�os para o produto " + descProd[i]);
			
			for ( int x = 0; x < 6; x++ ) {
				System.out.println("Loja " + nomeLojas[x]);
				
				precoStore[i][x] = input.nextDouble();
			}
		}
		
		input.close();
	}
}
