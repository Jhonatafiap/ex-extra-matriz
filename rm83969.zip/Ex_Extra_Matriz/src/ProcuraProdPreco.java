import java.util.Scanner;

public class ProcuraProdPreco {
	
	public void procura(int codProd[], String descProd[], String nomeLojas[], double precoStore[][]) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Qual o c�digo do produto que voc� desejar encontrar o menor pre�o?");
		int prodSearch = input.nextInt();
		int indiceProd = 0;
		boolean existe = false;
		
		for ( int i = 0; i < codProd.length; i++ ) {
			if ( codProd[i] == prodSearch ) {
				existe = true;
				indiceProd = i;
			}
		}
		
		if ( existe ) {
			double menorPreco;
			int indiceLoj = 0;
			
			for ( int i = 0; i < 6; i++ ) {
				
				menorPreco = precoStore[indiceProd][i];
				
				if ( precoStore[indiceProd][i] < menorPreco ) {
					
					precoStore[indiceProd][i] = menorPreco;
					indiceLoj = i;
				}
			}
		} else {
			System.out.println("C�DIGO DE PRODUTO INEXISTENTE");
		}
		
		input.close();
		
	}
}
