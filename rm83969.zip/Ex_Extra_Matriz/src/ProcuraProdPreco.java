
public class ProcuraProdPreco {
	public void procura() {
		
		
	}
}
