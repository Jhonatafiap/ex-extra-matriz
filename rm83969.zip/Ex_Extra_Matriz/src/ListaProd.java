
public class ListaProd {
	
	public void listar(int[] codProd, String[] descProd) {
		
		for ( int i = 0; i < codProd.length; i++ ) {
			System.out.println("Produto " + i+1);
			System.out.println("C�digo: " + codProd[i]);
			System.out.println("Descri��o: " + descProd[i]);
		}
	}
}
